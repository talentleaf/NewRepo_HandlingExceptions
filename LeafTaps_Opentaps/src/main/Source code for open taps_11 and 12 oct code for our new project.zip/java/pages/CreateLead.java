package pages;

import wrappers.LeafTapWrappers;

public class CreateLead extends LeafTapWrappers{

	public CreateLead()
	{
		if (verifyTitle("Create Lead | opentaps CRM")==false) {
			logSteps("fail", "Driver is not landed at Create Lead page");
		}	
	}	
	public CreateLead typeCompanyName()
	{
		enterById("createLeadForm_companyName", "CTS");
		return this;
	}
	
	public CreateLead typeFirstName()
	{
		enterById("createLeadForm_firstName", "karpa");
		return this;
	}
	
	public CreateLead typeLastName()
	{
		enterById("createLeadForm_lastName", "K");
		return this;
	}
	
	public ViewLead clickCreateLeadButton()
	{		
		clickByXpath("//input[@value='Create Lead']");
		return new ViewLead();
	}
}
