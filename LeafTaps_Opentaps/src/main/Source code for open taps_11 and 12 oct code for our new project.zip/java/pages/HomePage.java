package pages;

import wrappers.LeafTapWrappers;

public class HomePage extends LeafTapWrappers {

	public HomePage()
	{
		if (verifyTitle("Opentaps Open Source ERP + CRM")==false) {
			logSteps("fail", "Driver is not landed in the Home page");
		}	
	}	
	public MyHomePage clickCRMSFAlink()
	{
		clickByLink("CRM/SFA");
		return new MyHomePage();
	}
	public LoginPage clickLogOut()
	{
		clickByClassName("decorativeSubmit");
		return new LoginPage();
	}
}
