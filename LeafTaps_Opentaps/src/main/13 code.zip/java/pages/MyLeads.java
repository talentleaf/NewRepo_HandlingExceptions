package pages;

import wrappers.LeafTapWrappers;

public class MyLeads extends LeafTapWrappers{

	public MyLeads()
	{
		if (verifyTitle("My Leads | opentaps CRM")==false) {
			logSteps("fail", "Driver is not landed at My Lead page");
		}	
	}	
	public CreateLead clickCreateLeadTab()
	{
		clickByLink("Create Lead");
		return new CreateLead();
	}
}
