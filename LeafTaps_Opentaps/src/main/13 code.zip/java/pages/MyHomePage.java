package pages;

import wrappers.LeafTapWrappers;

public class MyHomePage extends LeafTapWrappers {

	public MyHomePage()
	{
		if (verifyTitle("My Home | opentaps CRM")==false) {
			logSteps("fail", "Driver is not landed at My Home page");
		}	
	}	
	public MyLeads clickLeadsTab()
	{
		clickByLink("Leads");
		return new MyLeads();
	}

}
