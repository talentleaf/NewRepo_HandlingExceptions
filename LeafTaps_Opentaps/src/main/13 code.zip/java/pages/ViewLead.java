package pages;

import wrappers.LeafTapWrappers;

public class ViewLead extends LeafTapWrappers{

	public ViewLead()
	{
		if (verifyTitle("View Lead | opentaps CRM")==false) {
			logSteps("fail", "Driver is not landed at View Lead page");
		}	
	}		
	public ViewLead verifyCompanyName(String companyName)
	{		
		boolean check=verifyTextById("viewLead_companyName_sp", companyName);
		return this;
	}
}
