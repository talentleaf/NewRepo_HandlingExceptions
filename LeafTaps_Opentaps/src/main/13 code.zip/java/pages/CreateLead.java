package pages;

import wrappers.LeafTapWrappers;

public class CreateLead extends LeafTapWrappers{

	public CreateLead()
	{
		if (verifyTitle("Create Lead | opentaps CRM")==false) {
			logSteps("fail", "Driver is not landed at Create Lead page");
		}	
	}	
	public CreateLead typeCompanyName(String companyName)
	{
		enterById("createLeadForm_companyName", companyName);
		return this;
	}
	
	public CreateLead typeFirstName(String firstName)
	{
		enterById("createLeadForm_firstName", firstName);
		return this;
	}
	
	public CreateLead typeLastName(String lastName)
	{
		enterById("createLeadForm_lastName", lastName);
		return this;
	}
	
	public ViewLead clickCreateLeadButton()
	{		
		clickByXpath("//input[@value='Create Lead']");
		return new ViewLead();
	}
}
