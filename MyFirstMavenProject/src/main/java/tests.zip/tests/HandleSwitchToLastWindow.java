package tests;

import java.util.Set;

import org.openqa.selenium.chrome.ChromeDriver;

import wrapper.GenericWrappers;

public class HandleSwitchToLastWindow {

	public static void main(String[] args) {
		/*System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver_win32(1)\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		String message=null;
		driver.get("https://www.irctc.co.in/eticketing/loginHome.jsf");
		driver.manage().window().maximize();*/
		
		GenericWrappers gw=new GenericWrappers();
		gw.invokeApp("chrome", "https://www.irctc.co.in/eticketing/loginHome.jsf");
		dr
		
		gw.switchToLastWindow();
//to print the child window url
System.out.println(driver.getCurrentUrl());
//to print child window title
System.out.println(driver.getTitle());


	}

}
