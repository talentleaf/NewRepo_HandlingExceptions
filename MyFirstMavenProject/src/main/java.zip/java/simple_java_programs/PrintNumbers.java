package simple_java_programs;

public class PrintNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Print Numbers from 1 to 50:");
		for(int i=1;i<=50;i++)
		{
			System.out.println(i);
		}
	}

}
